let s1 = "piyush";
let s2 = "vaghasiyA";
let s3 = s1 + " " + s2;
document.write(s3);